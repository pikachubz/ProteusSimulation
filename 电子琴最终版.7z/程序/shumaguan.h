#ifndef _SHUMAGUAN_H_
#define _SHUMAGUAN_H_

#include "music.h"


//void in(uchar Data);
//void out(void);
//void display1(void);
#endif