#ifndef _LCD1602_H_
#define _LCD1602_H_

#include <reg52.h> 
//#include "main.h"
#include "music.h"

#define LCD_DB  P0//����LCD�����ݶ˿�

sbit   LCD_RS=P2^0;
sbit   LCD_RW=P2^1;
sbit   LCD_E=P2^2;

void delay_lcd(uint x);
void LCD_write_command(uchar command);
void LCD_write_data(uchar dat);
void delay1(uint x);
void LCD_init(void);
void gotoxy(uchar x,uchar y);
void LCD_display(uchar *dat);
#endif