#ifndef __MAIN_H_
#define __MAIN_H_

#define uchar unsigned char
#define uint unsigned int
#define ulong	unsigned long

#include <reg52.h>
#include <intrins.h>
#include "dht11.h"
#include "lcd1602.h"
#include "adc.h"
#include "hMotor.h"
#include "ds1302.h"

void delay_ms(uint cnt);
void delay(uint i);
#endif