#include "main.h"

uchar wd_H = 20;
uchar wd_L = 30;
uchar sd_H = 40;
uchar sd_L = 50;
uchar wd[3],sd[3];

uchar cnt_100ms=0,cnt_500ms =0;
uchar time_100ms_flag;
//������ʱ1ms
void delay_ms(uint cnt)
{
	unsigned int x;
	for( ; cnt>0; cnt--)
	{
		for(x=110; x>0; x--);
	}
}

void delay(uint i)
{  
 while( i-- );
}

//��ʱ����ʼ��
void time_init(void)
{		
		EA=1;
//		TCON=0x05; //�ⲿ�ж�0,1����Ϊ���ش��� 
//		EX0=1;     //���ⲿ�ж�0
//		EX1=1;		 //���ⲿ�ж�1
	  TMOD |= 0x01;//time0 ������ʽΪ1
	  TH0 = 0xf8;//װ�س�ֵ
	  TL0 = 0x2f;//װ�س�ֵ��Ϊ2ms(65535-63535)
    TR0 = 1;//������ʱ��
	  ET0 = 1;//���ж�
	  
		
}
//��һ��ʱ���ȡ��ʪ������
void time_service(void)
{
	if(time_100ms_flag)
	{
		time_100ms_flag = 0;
		if (++cnt_500ms>1)
    {
			cnt_500ms = 0;                 
      EA = 0;
      DHT11_receive();
      EA = 1;
      wd[0]=WD_value/10+'0';
			wd[1]=WD_value%10+'0';
			sd[0]=SD_value/10+'0';
			sd[1]=SD_value%10+'0';        
    }
	}
}

void main()
{
	LED1=1;
	LED2=1;
	LED3=1;
	LED4=1;
	SD_motor=0;
	WD_motor=0;
	wd[2]='\0';
	sd[2]='\0';
	time_init();
	LCD_init();
	LCD_display_char(0,1,"WD:");
	LCD_display_char(0,2,"SD:");
	while(1)
	{	

		time_service();
		LCD_display_char(3,1,wd);
		LCD_display_char(3,2,sd);	
    DHT11_Warning(WD_value,SD_value,30,20,50,40);
//		delay_ms(500);
		getGuangqiang();
		getYanwu();
		chuangLian();
		get_1302(time_1302);
		DS1302_change();
		LCD_display_char(6,2,times);
//		delay_ms(50);
	}
}


void time0_interrupt() interrupt 1
{
	TF0 = 0;//�����־
	TR0 = 0;
	if (++cnt_100ms>50)
	{
		cnt_100ms = 0;
		time_100ms_flag = 1;
	}
	TR0 = 1;
	TH0 = 0xf8;
	TL0 = 0x2f;//װ�س�ֵ2ms(65535-63535)
}