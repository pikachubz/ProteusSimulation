#ifndef _MAIN_H_
#define _MAIN_H_

#define uchar unsigned char 
#define uint unsigned int

#include <reg51.h> 
#include <stdio.h>
#include <math.h>
#include "ds1302.h"
#include "lcd1602.h"

	
//��������
void delay_speed(uint time);
void ground(step_index);

#endif